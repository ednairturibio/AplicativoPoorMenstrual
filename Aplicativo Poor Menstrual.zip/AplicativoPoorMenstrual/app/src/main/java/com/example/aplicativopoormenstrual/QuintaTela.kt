package com.example.aplicativopoormenstrual

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class QuintaTela : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quinta_tela)
    }
}