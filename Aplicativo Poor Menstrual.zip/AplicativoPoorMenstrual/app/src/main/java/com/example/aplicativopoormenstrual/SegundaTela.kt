package com.example.aplicativopoormenstrual

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.aplicativopoormenstrual.databinding.ActivitySegundaTelaBinding

class SegundaTela : AppCompatActivity() {

    private lateinit var binding : ActivitySegundaTelaBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
    }
}